"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_secure_random_digit_1 = require("crypto-secure-random-digit");
const mail = require("@sendgrid/mail");
const AWS = require("aws-sdk");
mail.setApiKey("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");
const sns = new AWS.SNS({ apiVersion: '2010-03-31' });
exports.handler = async (event) => {
    let secretLoginCode;
    console.log("ATTR", event.request.userAttributes);
    let isEmail = event.request.userAttributes.email || false;
    if (!event.request.session || !event.request.session.length) {
        // This is a new auth session
        // Generate a new secret login code and mail it to the user
        secretLoginCode = crypto_secure_random_digit_1.randomDigits(6).join("");
        if (isEmail) {
            await sendEmail(event.request.userAttributes.email, secretLoginCode);
        }
        else {
            await sendSms(event.request.userAttributes.phone_number, secretLoginCode);
        }
    }
    else {
        // There's an existing session. Don't generate new digits but
        // re-use the code from the current session. This allows the user to
        // make a mistake when keying in the code and to then retry, rather
        // the needing to e-mail the user an all new code again.
        const previousChallenge = event.request.session.slice(-1)[0];
        secretLoginCode = previousChallenge.challengeMetadata.match(/CODE-(\d*)/)[1];
    }
    // This is sent back to the client app
    event.response.publicChallengeParameters = isEmail
        ? {
            email: event.request.userAttributes.email,
        }
        : { phone_number: event.request.userAttributes.phone_number };
    // Add the secret login code to the private challenge parameters
    // so it can be verified by the "Verify Auth Challenge Response" trigger
    event.response.privateChallengeParameters = { secretLoginCode };
    // Add the secret login code to the session so it is available
    // in a next invocation of the "Create Auth Challenge" trigger
    event.response.challengeMetadata = `CODE-${secretLoginCode}`;
    return event;
};
async function sendEmail(emailAddress, secretLoginCode) {
    const config = {
        email: "no-reply@spend-secure.com",
        name: "Spend Team",
        template_id: "d-14b75e7e581c42948449bd3d89baf1b9",
    };
    const options = {
        personalizations: [
            {
                to: [
                    {
                        email: emailAddress,
                        name: "",
                    },
                ],
                dynamic_template_data: {
                    OTPCode: secretLoginCode,
                    subject: `Your One Time Password`,
                    preheader: "This is valid por the next 3 minutes.",
                },
            },
        ],
        from: {
            email: config.email,
            name: config.name,
        },
        reply_to: {
            email: config.email,
            name: config.name,
        },
        templateId: config.template_id,
    };
    await mail.send(options);
}
async function sendSms(phone_number, secretLoginCode) {
    var params = {
        Message: `Your One Time password is: ${secretLoginCode}`,
        PhoneNumber: phone_number,
        MessageAttributes: {
            'AWS.SNS.SMS.SMSType': {
                'DataType': 'String',
                'StringValue': 'Transactional'
            }
        }
    };
    await sns.publish(params).promise();
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlQXV0aENoYWxsZW5nZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNyZWF0ZUF1dGhDaGFsbGVuZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSwyRUFBMEQ7QUFDMUQsdUNBQXVDO0FBQ3ZDLCtCQUErQjtBQUUvQixJQUFJLENBQUMsU0FBUyxDQUNWLHVFQUF1RSxDQUMxRSxDQUFDO0FBRUYsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUM7QUFFekMsUUFBQSxPQUFPLEdBQWtDLEtBQUssRUFDdkQsS0FBa0MsRUFDcEMsRUFBRTtJQUNBLElBQUksZUFBdUIsQ0FBQztJQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBRWxELElBQUksT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUM7SUFFMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO1FBQ3pELDZCQUE2QjtRQUM3QiwyREFBMkQ7UUFDM0QsZUFBZSxHQUFHLHlDQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRTNDLElBQUksT0FBTyxFQUFFO1lBQ1QsTUFBTSxTQUFTLENBQ1gsS0FBSyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUNsQyxlQUFlLENBQ2xCLENBQUM7U0FDTDthQUFNO1lBQ0gsTUFBTSxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLGVBQWUsQ0FBQyxDQUFBO1NBQzVFO0tBQ0o7U0FBTTtRQUNILDZEQUE2RDtRQUM3RCxvRUFBb0U7UUFDcEUsbUVBQW1FO1FBQ25FLHdEQUF3RDtRQUN4RCxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdELGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxpQkFBa0IsQ0FBQyxLQUFLLENBQ3hELFlBQVksQ0FDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ1Q7SUFFRCxzQ0FBc0M7SUFDdEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsR0FBRyxPQUFPO1FBQzlDLENBQUMsQ0FBQztZQUNJLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxLQUFLO1NBQzVDO1FBQ0gsQ0FBQyxDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxDQUFDO0lBRWxFLGdFQUFnRTtJQUNoRSx3RUFBd0U7SUFDeEUsS0FBSyxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsR0FBRyxFQUFFLGVBQWUsRUFBRSxDQUFDO0lBRWhFLDhEQUE4RDtJQUM5RCw4REFBOEQ7SUFDOUQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLGVBQWUsRUFBRSxDQUFDO0lBRTdELE9BQU8sS0FBSyxDQUFDO0FBQ2pCLENBQUMsQ0FBQztBQUVGLEtBQUssVUFBVSxTQUFTLENBQUMsWUFBb0IsRUFBRSxlQUF1QjtJQUNsRSxNQUFNLE1BQU0sR0FBRztRQUNYLEtBQUssRUFBRSwyQkFBMkI7UUFDbEMsSUFBSSxFQUFFLFlBQVk7UUFDbEIsV0FBVyxFQUFFLG9DQUFvQztLQUNwRCxDQUFDO0lBRUYsTUFBTSxPQUFPLEdBQUc7UUFDWixnQkFBZ0IsRUFBRTtZQUNkO2dCQUNJLEVBQUUsRUFBRTtvQkFDQTt3QkFDSSxLQUFLLEVBQUUsWUFBWTt3QkFDbkIsSUFBSSxFQUFFLEVBQUU7cUJBQ1g7aUJBQ0o7Z0JBQ0QscUJBQXFCLEVBQUU7b0JBQ25CLE9BQU8sRUFBRSxlQUFlO29CQUN4QixPQUFPLEVBQUUsd0JBQXdCO29CQUNqQyxTQUFTLEVBQUUsdUNBQXVDO2lCQUNyRDthQUNKO1NBQ0o7UUFDRCxJQUFJLEVBQUU7WUFDRixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO1NBQ3BCO1FBQ0QsUUFBUSxFQUFFO1lBQ04sS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtTQUNwQjtRQUNELFVBQVUsRUFBRSxNQUFNLENBQUMsV0FBVztLQUNqQyxDQUFDO0lBRUYsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdCLENBQUM7QUFFRCxLQUFLLFVBQVUsT0FBTyxDQUFDLFlBQW9CLEVBQUUsZUFBdUI7SUFDaEUsSUFBSSxNQUFNLEdBQUc7UUFDVCxPQUFPLEVBQUUsOEJBQThCLGVBQWUsRUFBRTtRQUN4RCxXQUFXLEVBQUUsWUFBWTtRQUN6QixpQkFBaUIsRUFBRTtZQUNmLHFCQUFxQixFQUFFO2dCQUNuQixVQUFVLEVBQUUsUUFBUTtnQkFDcEIsYUFBYSxFQUFFLGVBQWU7YUFDakM7U0FDSjtLQUNKLENBQUM7SUFFRixNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDeEMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gICAgQ29nbml0b1VzZXJQb29sVHJpZ2dlckhhbmRsZXIsXG4gICAgQ29nbml0b1VzZXJQb29sVHJpZ2dlckV2ZW50LFxufSBmcm9tIFwiYXdzLWxhbWJkYVwiO1xuaW1wb3J0IHsgcmFuZG9tRGlnaXRzIH0gZnJvbSBcImNyeXB0by1zZWN1cmUtcmFuZG9tLWRpZ2l0XCI7XG5pbXBvcnQgKiBhcyBtYWlsIGZyb20gXCJAc2VuZGdyaWQvbWFpbFwiO1xuaW1wb3J0ICogYXMgQVdTIGZyb20gJ2F3cy1zZGsnO1xuXG5tYWlsLnNldEFwaUtleShcbiAgICBcIlNHLmZPT3BvX3I0UkRXc1dSNzgwS2JqQlEueWU2bmNLT3BlM2d2TW4xUnNuUjlscDQwd1pSUlY5MDNOU0dGbklwODNuTVwiXG4pO1xuXG5jb25zdCBzbnMgPSBuZXcgQVdTLlNOUyh7IGFwaVZlcnNpb246ICcyMDEwLTAzLTMxJyB9KTtcblxuZXhwb3J0IGNvbnN0IGhhbmRsZXI6IENvZ25pdG9Vc2VyUG9vbFRyaWdnZXJIYW5kbGVyID0gYXN5bmMgKFxuICAgIGV2ZW50OiBDb2duaXRvVXNlclBvb2xUcmlnZ2VyRXZlbnRcbikgPT4ge1xuICAgIGxldCBzZWNyZXRMb2dpbkNvZGU6IHN0cmluZztcbiAgICBjb25zb2xlLmxvZyhcIkFUVFJcIiwgZXZlbnQucmVxdWVzdC51c2VyQXR0cmlidXRlcyk7XG5cbiAgICBsZXQgaXNFbWFpbCA9IGV2ZW50LnJlcXVlc3QudXNlckF0dHJpYnV0ZXMuZW1haWwgfHwgZmFsc2U7XG5cbiAgICBpZiAoIWV2ZW50LnJlcXVlc3Quc2Vzc2lvbiB8fCAhZXZlbnQucmVxdWVzdC5zZXNzaW9uLmxlbmd0aCkge1xuICAgICAgICAvLyBUaGlzIGlzIGEgbmV3IGF1dGggc2Vzc2lvblxuICAgICAgICAvLyBHZW5lcmF0ZSBhIG5ldyBzZWNyZXQgbG9naW4gY29kZSBhbmQgbWFpbCBpdCB0byB0aGUgdXNlclxuICAgICAgICBzZWNyZXRMb2dpbkNvZGUgPSByYW5kb21EaWdpdHMoNikuam9pbihcIlwiKTtcblxuICAgICAgICBpZiAoaXNFbWFpbCkge1xuICAgICAgICAgICAgYXdhaXQgc2VuZEVtYWlsKFxuICAgICAgICAgICAgICAgIGV2ZW50LnJlcXVlc3QudXNlckF0dHJpYnV0ZXMuZW1haWwsXG4gICAgICAgICAgICAgICAgc2VjcmV0TG9naW5Db2RlXG4gICAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgc2VuZFNtcyhldmVudC5yZXF1ZXN0LnVzZXJBdHRyaWJ1dGVzLnBob25lX251bWJlciwgc2VjcmV0TG9naW5Db2RlKVxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVGhlcmUncyBhbiBleGlzdGluZyBzZXNzaW9uLiBEb24ndCBnZW5lcmF0ZSBuZXcgZGlnaXRzIGJ1dFxuICAgICAgICAvLyByZS11c2UgdGhlIGNvZGUgZnJvbSB0aGUgY3VycmVudCBzZXNzaW9uLiBUaGlzIGFsbG93cyB0aGUgdXNlciB0b1xuICAgICAgICAvLyBtYWtlIGEgbWlzdGFrZSB3aGVuIGtleWluZyBpbiB0aGUgY29kZSBhbmQgdG8gdGhlbiByZXRyeSwgcmF0aGVyXG4gICAgICAgIC8vIHRoZSBuZWVkaW5nIHRvIGUtbWFpbCB0aGUgdXNlciBhbiBhbGwgbmV3IGNvZGUgYWdhaW4uXG4gICAgICAgIGNvbnN0IHByZXZpb3VzQ2hhbGxlbmdlID0gZXZlbnQucmVxdWVzdC5zZXNzaW9uLnNsaWNlKC0xKVswXTtcbiAgICAgICAgc2VjcmV0TG9naW5Db2RlID0gcHJldmlvdXNDaGFsbGVuZ2UuY2hhbGxlbmdlTWV0YWRhdGEhLm1hdGNoKFxuICAgICAgICAgICAgL0NPREUtKFxcZCopL1xuICAgICAgICApIVsxXTtcbiAgICB9XG5cbiAgICAvLyBUaGlzIGlzIHNlbnQgYmFjayB0byB0aGUgY2xpZW50IGFwcFxuICAgIGV2ZW50LnJlc3BvbnNlLnB1YmxpY0NoYWxsZW5nZVBhcmFtZXRlcnMgPSBpc0VtYWlsXG4gICAgICAgID8ge1xuICAgICAgICAgICAgICBlbWFpbDogZXZlbnQucmVxdWVzdC51c2VyQXR0cmlidXRlcy5lbWFpbCxcbiAgICAgICAgICB9XG4gICAgICAgIDogeyBwaG9uZV9udW1iZXI6IGV2ZW50LnJlcXVlc3QudXNlckF0dHJpYnV0ZXMucGhvbmVfbnVtYmVyIH07XG5cbiAgICAvLyBBZGQgdGhlIHNlY3JldCBsb2dpbiBjb2RlIHRvIHRoZSBwcml2YXRlIGNoYWxsZW5nZSBwYXJhbWV0ZXJzXG4gICAgLy8gc28gaXQgY2FuIGJlIHZlcmlmaWVkIGJ5IHRoZSBcIlZlcmlmeSBBdXRoIENoYWxsZW5nZSBSZXNwb25zZVwiIHRyaWdnZXJcbiAgICBldmVudC5yZXNwb25zZS5wcml2YXRlQ2hhbGxlbmdlUGFyYW1ldGVycyA9IHsgc2VjcmV0TG9naW5Db2RlIH07XG5cbiAgICAvLyBBZGQgdGhlIHNlY3JldCBsb2dpbiBjb2RlIHRvIHRoZSBzZXNzaW9uIHNvIGl0IGlzIGF2YWlsYWJsZVxuICAgIC8vIGluIGEgbmV4dCBpbnZvY2F0aW9uIG9mIHRoZSBcIkNyZWF0ZSBBdXRoIENoYWxsZW5nZVwiIHRyaWdnZXJcbiAgICBldmVudC5yZXNwb25zZS5jaGFsbGVuZ2VNZXRhZGF0YSA9IGBDT0RFLSR7c2VjcmV0TG9naW5Db2RlfWA7XG5cbiAgICByZXR1cm4gZXZlbnQ7XG59O1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kRW1haWwoZW1haWxBZGRyZXNzOiBzdHJpbmcsIHNlY3JldExvZ2luQ29kZTogc3RyaW5nKSB7XG4gICAgY29uc3QgY29uZmlnID0ge1xuICAgICAgICBlbWFpbDogXCJuby1yZXBseUBzcGVuZC1zZWN1cmUuY29tXCIsXG4gICAgICAgIG5hbWU6IFwiU3BlbmQgVGVhbVwiLFxuICAgICAgICB0ZW1wbGF0ZV9pZDogXCJkLTE0Yjc1ZTdlNTgxYzQyOTQ4NDQ5YmQzZDg5YmFmMWI5XCIsXG4gICAgfTtcblxuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgIHBlcnNvbmFsaXphdGlvbnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0bzogW1xuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogZW1haWxBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIGR5bmFtaWNfdGVtcGxhdGVfZGF0YToge1xuICAgICAgICAgICAgICAgICAgICBPVFBDb2RlOiBzZWNyZXRMb2dpbkNvZGUsXG4gICAgICAgICAgICAgICAgICAgIHN1YmplY3Q6IGBZb3VyIE9uZSBUaW1lIFBhc3N3b3JkYCxcbiAgICAgICAgICAgICAgICAgICAgcHJlaGVhZGVyOiBcIlRoaXMgaXMgdmFsaWQgcG9yIHRoZSBuZXh0IDMgbWludXRlcy5cIixcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgZnJvbToge1xuICAgICAgICAgICAgZW1haWw6IGNvbmZpZy5lbWFpbCxcbiAgICAgICAgICAgIG5hbWU6IGNvbmZpZy5uYW1lLFxuICAgICAgICB9LFxuICAgICAgICByZXBseV90bzoge1xuICAgICAgICAgICAgZW1haWw6IGNvbmZpZy5lbWFpbCxcbiAgICAgICAgICAgIG5hbWU6IGNvbmZpZy5uYW1lLFxuICAgICAgICB9LFxuICAgICAgICB0ZW1wbGF0ZUlkOiBjb25maWcudGVtcGxhdGVfaWQsXG4gICAgfTtcblxuICAgIGF3YWl0IG1haWwuc2VuZChvcHRpb25zKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2VuZFNtcyhwaG9uZV9udW1iZXI6IHN0cmluZywgc2VjcmV0TG9naW5Db2RlOiBzdHJpbmcpIHtcbiAgICB2YXIgcGFyYW1zID0ge1xuICAgICAgICBNZXNzYWdlOiBgWW91ciBPbmUgVGltZSBwYXNzd29yZCBpczogJHtzZWNyZXRMb2dpbkNvZGV9YCxcbiAgICAgICAgUGhvbmVOdW1iZXI6IHBob25lX251bWJlcixcbiAgICAgICAgTWVzc2FnZUF0dHJpYnV0ZXM6IHtcbiAgICAgICAgICAgICdBV1MuU05TLlNNUy5TTVNUeXBlJzoge1xuICAgICAgICAgICAgICAgICdEYXRhVHlwZSc6ICdTdHJpbmcnLFxuICAgICAgICAgICAgICAgICdTdHJpbmdWYWx1ZSc6ICdUcmFuc2FjdGlvbmFsJ1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcblxuICAgIGF3YWl0IHNucy5wdWJsaXNoKHBhcmFtcykucHJvbWlzZSgpO1xufVxuIl19