import { CognitoUserPoolTriggerHandler } from 'aws-lambda';
export declare const handler: CognitoUserPoolTriggerHandler;
